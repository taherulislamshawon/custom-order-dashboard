=== Custom WooCommerce Order Dashboard ===
Contributors: taherulislamshawon
Tags: woocommerce, admin dashboard, order management, order status, custom dashboard
Requires at least: 5.5
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight custom WooCommerce order management dashboard for administrators with order count and status summary view.

== Description ==

This plugin adds a custom admin dashboard for users with `manage_woocommerce` capability to view WooCommerce order status summaries. Each status includes a colored card and clickable link to the corresponding order list.

== Installation ==

1. Upload the plugin ZIP file via WordPress Dashboard > Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Use the shortcode `[order_dashboard]` in any page to display the order summary dashboard.

== Frequently Asked Questions ==

= Who can access the dashboard? =
Only users with the `manage_woocommerce` capability (e.g., shop managers, administrators).

= Can I modify the status colors? =
Yes, you can edit the PHP file and update the HEX color codes.

== Changelog ==

= 1.0 =
* Initial release with custom WooCommerce order summary dashboard.

== Upgrade Notice ==

= 1.0 =
First public release.

== Screenshots ==

1. Order status table with color indicators.
2. Mobile responsive view of the dashboard.