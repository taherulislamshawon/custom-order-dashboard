<?php
/**
 * Plugin Name: Custom Order Dashboard
 * Description: A custom dashboard for managing orders in WordPress.
 * Version: 1.0.0
 * Author: Taherul Islam Shawon
 * Author URI: https://github.com/taherulislamshawon
 * License: GPL2
 * Text Domain: custom-order-dashboard
 */

// Add your plugin code here

// নিরাপত্তার জন্য সরাসরি অ্যাক্সেস ব্লক করা
if (!defined('ABSPATH')) {
    exit;
}

// Shortcode ফাংশন
function custom_order_dashboard_shortcode() {
    if (!current_user_can('manage_woocommerce')) {
        return '<p>You do not have permission to view this dashboard.</p>';
    }

    $statuses = [
        'processing' => ['Processing', '#42a5f5', '/orders-processing', 'fa fa-cogs'],
        'pending' => ['Pending Payment', '#ffb74d', '/orders-pending-payment', 'fa fa-clock'],
        'on-hold' => ['On Hold', '#9575cd', '/orders-on-hold', 'fa fa-pause'],
        'completed' => ['Completed', '#388e3c', '/orders-completed', 'fa fa-check-circle'],
        'cancelled' => ['Cancelled', '#c62828', '/orders-cancelled', 'fa fa-times-circle'],
        'refunded' => ['Refunded', '#ab47bc', '/orders-refunded', 'fa fa-undo'],
        'failed' => ['Failed', '#ff7043', '/orders-failed', 'fa fa-exclamation-circle'],
        'shipped' => ['Shipped', '#29b6f6', '/orders-shipped', 'fa fa-truck'],
        'delivered' => ['Delivered', '#8bc34a', '/orders-delivered', 'fa fa-gift'],
    ];

    ob_start();

    // Dashboard HTML শুরু
    echo '<div class="order-dashboard-wrapper">';
    echo '<table class="order-dashboard-table">';
    echo '<thead><tr><th>Status</th><th>Total Orders</th></tr></thead>';
    echo '<tbody>';

    foreach ($statuses as $status_slug => [$status_label, $bg_color, $page_url, $icon_class]) {
        $orders = wc_get_orders([
            'status' => $status_slug,
            'limit' => -1,
            'return' => 'ids'
        ]);
        $count = count($orders);
        echo "<tr style='background-color: {$bg_color}; color: #fff;'>
                <td data-label='Status' style='padding-left:30px; padding-right:30px;'>
                    <a href='{$page_url}' style='color: #fff; text-decoration: underline;'>
                        <i class='{$icon_class}' style='margin-right: 8px;'></i>{$status_label}
                    </a>
                </td>
                <td data-label='Total Orders' style='text-align:center;'>{$count}</td>
              </tr>";
    }

    echo '</tbody></table></div>';

    // CSS ইনক্লুড করা
    wp_enqueue_style('custom-order-dashboard-css', plugin_dir_url(__FILE__) . 'assets/style.css');

    return ob_get_clean();
}
add_shortcode('order_dashboard', 'custom_order_dashboard_shortcode');