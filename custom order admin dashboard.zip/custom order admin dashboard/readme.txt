=== Custom Order Dashboard ===
Contributors: taherulislamshawon
Tags: dashboard, order management
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 1.0.0
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

A custom WordPress dashboard for managing orders, with features for order status updates and viewing orders by status.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/custom-order-dashboard` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==

= 1.0.0 =
* Initial release.

== Frequently Asked Questions ==

= Does this plugin work with WooCommerce? =
Yes, it integrates with WooCommerce for order management.

== License ==

This plugin is licensed under GPL2.